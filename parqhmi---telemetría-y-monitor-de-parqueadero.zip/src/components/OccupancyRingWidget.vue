<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, computed } from 'vue';
import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { OccupancyRingChart } from './OccupancyRingChart';
import type { EspacioInfo } from '../types/parqueadero';

const props = withDefaults(
  defineProps<{
    espacios: EspacioInfo[];
    disponiblesCount: number;
    totalEspacios: number;
    talanqueraBloqueada?: boolean;
  }>(),
  {
    talanqueraBloqueada: false,
  }
);

const containerRef = ref<HTMLDivElement | null>(null);
const isCollapsed = ref<boolean>(false);
let reactRoot: Root | null = null;

const ocupados = computed(() => {
  return props.espacios.filter((e) => e.estado === 'OCUPADO').length;
});

const porcentaje = computed(() => {
  if (props.totalEspacios === 0) return 0;
  return Math.round((ocupados.value / props.totalEspacios) * 100);
});

const estudiantesOcupados = computed(() => {
  return props.espacios.filter((e) => e.posicion.y < 50 && e.estado === 'OCUPADO').length;
});

const estudiantesTotal = computed(() => {
  const count = props.espacios.filter((e) => e.posicion.y < 50).length;
  return count || 5;
});

const docentesOcupados = computed(() => {
  return props.espacios.filter((e) => e.posicion.y >= 50 && e.estado === 'OCUPADO').length;
});

const docentesTotal = computed(() => {
  const count = props.espacios.filter((e) => e.posicion.y >= 50).length;
  return count || 5;
});

function renderReactChart() {
  if (!containerRef.value) return;

  if (!reactRoot) {
    reactRoot = createRoot(containerRef.value);
  }

  reactRoot.render(
    React.createElement(OccupancyRingChart, {
      ocupados: ocupados.value,
      disponibles: props.disponiblesCount,
      total: props.totalEspacios,
      porcentaje: porcentaje.value,
      talanqueraBloqueada: props.talanqueraBloqueada,
      estudiantesOcupados: estudiantesOcupados.value,
      estudiantesTotal: estudiantesTotal.value,
      docentesOcupados: docentesOcupados.value,
      docentesTotal: docentesTotal.value,
    })
  );
}

onMounted(() => {
  if (!isCollapsed.value) {
    renderReactChart();
  }
});

watch(
  [
    ocupados,
    () => props.disponiblesCount,
    () => props.totalEspacios,
    porcentaje,
    () => props.talanqueraBloqueada,
    isCollapsed,
  ],
  () => {
    if (!isCollapsed.value) {
      renderReactChart();
    }
  },
  { deep: true }
);

onUnmounted(() => {
  if (reactRoot) {
    reactRoot.unmount();
    reactRoot = null;
  }
});

function toggleCollapse() {
  isCollapsed.value = !isCollapsed.value;
  if (!isCollapsed.value) {
    setTimeout(renderReactChart, 50);
  }
}
</script>

<template>
  <div
    class="absolute top-2 right-2 z-30 transition-all duration-300 ease-in-out select-none"
    :class="isCollapsed ? 'w-auto' : 'w-36 sm:w-40'"
  >
    <!-- Contenedor flotante con estilo glassmorphism elegante y tamaño ultra compacto -->
    <div
      class="bg-white/95 backdrop-blur-md rounded-xl border border-slate-200/90 shadow-md overflow-hidden transition-all duration-300"
      :class="isCollapsed ? 'p-1.5' : 'p-2'"
    >
      <!-- Barra superior con botón para colapsar/expandir -->
      <div class="flex items-center justify-between" :class="isCollapsed ? 'gap-1.5' : 'mb-1'">
        <!-- Modo colapsado: Chip compacto con porcentaje -->
        <button
          v-if="isCollapsed"
          @click="toggleCollapse"
          class="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors cursor-pointer text-[11px] font-bold"
          title="Expandir gráfico Recharts"
        >
          <span
            class="w-2 h-2 rounded-full"
            :class="
              talanqueraBloqueada
                ? 'bg-red-500'
                : disponiblesCount === 0
                ? 'bg-amber-500'
                : 'bg-emerald-500 animate-pulse'
            "
          />
          <span class="font-mono text-emerald-800 font-extrabold">{{ porcentaje }}%</span>
          <span class="text-[9px] text-slate-500 uppercase tracking-wide">Aforo</span>
          <svg class="w-3 h-3 text-slate-400 ml-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        <!-- Modo expandido: Botón discreto para minimizar -->
        <template v-else>
          <span class="text-[8.5px] font-extrabold tracking-wider text-slate-400 uppercase font-mono">
            RECHARTS
          </span>
          <button
            @click="toggleCollapse"
            class="p-0.5 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Minimizar gráfico"
          >
            <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 15l7-7 7 7" />
            </svg>
          </button>
        </template>
      </div>

      <!-- Contenedor del gráfico React Recharts -->
      <div v-show="!isCollapsed" ref="containerRef" class="w-full" />
    </div>
  </div>
</template>
