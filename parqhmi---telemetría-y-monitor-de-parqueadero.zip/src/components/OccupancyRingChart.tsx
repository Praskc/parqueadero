import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

export interface OccupancyRingChartProps {
  ocupados: number;
  disponibles: number;
  total: number;
  porcentaje: number;
  talanqueraBloqueada?: boolean;
  estudiantesOcupados?: number;
  estudiantesTotal?: number;
  docentesOcupados?: number;
  docentesTotal?: number;
}

export const OccupancyRingChart: React.FC<OccupancyRingChartProps> = ({
  ocupados,
  disponibles,
  total,
  porcentaje,
  talanqueraBloqueada = false,
  estudiantesOcupados = 0,
  estudiantesTotal = 5,
  docentesOcupados = 0,
  docentesTotal = 5,
}) => {
  const isFull = disponibles === 0;

  // Color de estado según el nivel de ocupación
  const ringColor = talanqueraBloqueada
    ? '#dc2626' // Rojo bloqueo
    : isFull
    ? '#dc2626' // Rojo lleno
    : porcentaje >= 70
    ? '#ea580c' // Naranja aforo alto
    : porcentaje >= 40
    ? '#ca8a04' // Amarillo medio
    : '#16a34a'; // Verde óptimo

  // Datos para el anillo exterior principal (Ocupación Total)
  // Manejo de caso cuando ambos son 0 para evitar anillo roto
  const totalData = total === 0 ? [
    { name: 'Sin datos', value: 1, color: '#e2e8f0' }
  ] : [
    { name: 'Ocupadas', value: ocupados, color: ringColor },
    { name: 'Disponibles', value: disponibles, color: '#f1f5f9' },
  ];

  // Datos para el anillo interior (Desglose por zonas: Estudiantes y Docentes)
  const zoneData = [
    { name: 'Estudiantes Ocup.', value: estudiantesOcupados, color: '#0284c7' },
    { name: 'Estudiantes Libres', value: Math.max(0, estudiantesTotal - estudiantesOcupados), color: '#e0f2fe' },
    { name: 'Docentes Ocup.', value: docentesOcupados, color: '#7c3aed' },
    { name: 'Docentes Libres', value: Math.max(0, docentesTotal - docentesOcupados), color: '#ede9fe' },
  ];

  return (
    <div className="flex flex-col gap-1.5 w-full">
      {/* Cabecera compacta */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-1">
        <div className="flex items-center gap-1">
          <span className="relative flex h-1.5 w-1.5">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                talanqueraBloqueada ? 'bg-red-400' : isFull ? 'bg-amber-400' : 'bg-emerald-400'
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-1.5 w-1.5 ${
                talanqueraBloqueada ? 'bg-red-500' : isFull ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
            />
          </span>
          <span className="text-[9px] font-extrabold tracking-wider text-slate-700 uppercase font-mono">
            OCUPACIÓN
          </span>
        </div>
        <span
          className={`text-[8px] font-bold px-1 py-0.2 rounded ${
            talanqueraBloqueada
              ? 'bg-red-100 text-red-700'
              : isFull
              ? 'bg-amber-100 text-amber-800'
              : 'bg-emerald-100 text-emerald-800'
          }`}
        >
          {talanqueraBloqueada ? 'BLOQ' : isFull ? 'LLENO' : `${porcentaje}%`}
        </span>
      </div>

      {/* Gráfico de Anillos Recharts Compacto */}
      <div className="relative w-full h-[76px] flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            {/* Anillo Interior: Segmentación Estudiantes vs Docentes */}
            <Pie
              data={zoneData}
              dataKey="value"
              cx="50%"
              cy="50%"
              innerRadius={17}
              outerRadius={24}
              stroke="#ffffff"
              strokeWidth={1}
              isAnimationActive={true}
              animationDuration={400}
            >
              {zoneData.map((entry, index) => (
                <Cell key={`zone-cell-${index}`} fill={entry.color} />
              ))}
            </Pie>

            {/* Anillo Exterior Principal: Ocupadas vs Libres */}
            <Pie
              data={totalData}
              dataKey="value"
              cx="50%"
              cy="50%"
              innerRadius={27}
              outerRadius={36}
              stroke="#ffffff"
              strokeWidth={1.5}
              startAngle={90}
              endAngle={-270}
              isAnimationActive={true}
              animationDuration={500}
            >
              {totalData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>

            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0];
                  return (
                    <div className="bg-slate-900/95 text-white text-[9px] px-1.5 py-0.5 rounded shadow border border-slate-700">
                      <span className="font-semibold">{data.name}:</span> {data.value}
                    </div>
                  );
                }
                return null;
              }}
            />
          </PieChart>
        </ResponsiveContainer>

        {/* Centro del Anillo: Porcentaje Compacto */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span
            className="text-xs font-black tracking-tight leading-none font-mono"
            style={{ color: ringColor }}
          >
            {porcentaje}%
          </span>
          <span className="text-[7px] font-bold text-slate-400 uppercase tracking-tighter">
            AFORO
          </span>
        </div>
      </div>

      {/* Métricas compactas en 1 sola fila */}
      <div className="flex items-center justify-between text-[9px] bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
        <span className="text-slate-500 font-medium">
          Ocup: <b className="text-slate-800 font-mono">{ocupados}/{total}</b>
        </span>
        <span className="text-slate-300">|</span>
        <span className="text-slate-500 font-medium">
          Libres: <b className="text-emerald-700 font-mono">{disponibles}</b>
        </span>
      </div>

      {/* Mini desglose por zona */}
      <div className="flex items-center justify-between text-[8px] text-slate-500 px-0.5">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
          Est: {estudiantesOcupados}/{estudiantesTotal}
        </span>
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
          Doc: {docentesOcupados}/{docentesTotal}
        </span>
      </div>
    </div>
  );
};

export default OccupancyRingChart;
