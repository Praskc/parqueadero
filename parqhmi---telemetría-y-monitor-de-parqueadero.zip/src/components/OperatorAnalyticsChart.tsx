import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadialBarChart,
  RadialBar,
} from 'recharts';
import type { EspacioInfo, EstadoTalanquera } from '../types/parqueadero';

export interface OperatorAnalyticsProps {
  espacios: EspacioInfo[];
  disponiblesCount: number;
  totalEspacios: number;
  barrierState: EstadoTalanquera;
  talanqueraBloqueada: boolean;
  isAutoSimRunning: boolean;
}

export const OperatorAnalyticsChart: React.FC<OperatorAnalyticsProps> = ({
  espacios,
  disponiblesCount,
  totalEspacios,
  barrierState,
  talanqueraBloqueada,
}) => {
  const [activeChartTab, setActiveChartTab] = useState<'flujo' | 'bahias' | 'zonas' | 'rendimiento'>('flujo');

  const ocupadosCount = totalEspacios - disponiblesCount;
  const porcentajeOcupacion = totalEspacios > 0 ? Math.round((ocupadosCount / totalEspacios) * 100) : 0;

  // Separación por zonas: Estudiantes (E01-E05) vs Docentes (E06-E10)
  const estudiantesOcupados = espacios.filter((e) => e.posicion.y < 50 && e.estado === 'OCUPADO').length;
  const estudiantesTotal = espacios.filter((e) => e.posicion.y < 50).length || 5;
  const estudiantesLibres = Math.max(0, estudiantesTotal - estudiantesOcupados);

  const docentesOcupados = espacios.filter((e) => e.posicion.y >= 50 && e.estado === 'OCUPADO').length;
  const docentesTotal = espacios.filter((e) => e.posicion.y >= 50).length || 5;
  const docentesLibres = Math.max(0, docentesTotal - docentesOcupados);

  // 1. Datos simulados de flujo horario (Ingresos vs Salidas) a lo largo del día universitario en Unisucre
  const datosFlujoHorario = useMemo(() => [
    { hora: '06:00', ingresos: 2, salidas: 0, ocupacion: 2 },
    { hora: '07:00', ingresos: 8, salidas: 1, ocupacion: 9 },
    { hora: '08:00', ingresos: 7, salidas: 3, ocupacion: 10 },
    { hora: '09:00', ingresos: 4, salidas: 5, ocupacion: 9 },
    { hora: '10:00', ingresos: 5, salidas: 4, ocupacion: 10 },
    { hora: '11:00', ingresos: 3, salidas: 6, ocupacion: 7 },
    { hora: '12:00', ingresos: 4, salidas: 7, ocupacion: 4 },
    { hora: '13:00', ingresos: 8, salidas: 2, ocupacion: 10 },
    { hora: '14:00', ingresos: 6, salidas: 4, ocupacion: 10 },
    { hora: '15:00', ingresos: 5, salidas: 5, ocupacion: 10 },
    { hora: '16:00', ingresos: 3, salidas: 6, ocupacion: 7 },
    { hora: '17:00', ingresos: 2, salidas: 7, ocupacion: 2 },
    { hora: '18:00', ingresos: 1, salidas: 2, ocupacion: 1 },
  ], []);

  // 2. Datos individuales por bahía (E01 a E10) con estado real y rotación estimada
  const datosBahias = useMemo(() => {
    return espacios.map((esp, idx) => {
      const isOccupied = esp.estado === 'OCUPADO';
      // Rotaciones base simuladas por bahía
      const baseRotacion = [6, 8, 7, 9, 5, 8, 10, 6, 7, 5][idx % 10] || 6;
      return {
        id: esp.id,
        nombre: esp.id,
        zona: esp.posicion.y < 50 ? 'Estudiantes' : 'Docentes',
        estado: esp.estado,
        valorOcupado: isOccupied ? 1 : 0,
        rotacionesHoy: baseRotacion + (isOccupied ? 1 : 0),
        color: isOccupied ? '#ef4444' : '#10b981',
      };
    });
  }, [espacios]);

  // 3. Distribución por Categorías de Usuarios y Zonas
  const datosDistribucionZonas = useMemo(() => [
    { name: 'Estudiantes (Ocupadas)', value: estudiantesOcupados, color: '#0284c7' },
    { name: 'Estudiantes (Libres)', value: estudiantesLibres, color: '#bae6fd' },
    { name: 'Docentes (Ocupadas)', value: docentesOcupados, color: '#7c3aed' },
    { name: 'Docentes (Libres)', value: docentesLibres, color: '#ddd6fe' },
  ], [estudiantesOcupados, estudiantesLibres, docentesOcupados, docentesLibres]);

  // 4. Medidores de rendimiento / KPIs para gráfico radial
  const datosRendimiento = useMemo(() => [
    {
      name: 'Ocupación',
      valor: porcentajeOcupacion,
      fill: porcentajeOcupacion > 80 ? '#ef4444' : porcentajeOcupacion > 50 ? '#f59e0b' : '#10b981',
    },
    {
      name: 'Eficiencia',
      valor: 94,
      fill: '#0284c7',
    },
    {
      name: 'Disponibilidad Talanquera',
      valor: talanqueraBloqueada ? 0 : 99,
      fill: talanqueraBloqueada ? '#dc2626' : '#10b981',
    },
  ], [porcentajeOcupacion, talanqueraBloqueada]);

  // Datos para gráfico de tráfico por carril de acceso (Norte vs Sur)
  const datosCarriles = useMemo(() => [
    { carril: 'Carril Norte', ingresos: 58, porcentaje: 52, color: '#059669' },
    { carril: 'Carril Sur', ingresos: 54, porcentaje: 48, color: '#0284c7' },
  ], []);

  return (
    <div className="flex flex-col gap-4 w-full">
      {/* Selector de tipo de gráfico con iconos SVG */}
      <div className="flex items-center justify-between flex-wrap gap-2 border-b border-slate-200 pb-2.5">
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveChartTab('flujo')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeChartTab === 'flujo'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {/* SVG Icon AreaChart / Trending */}
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
            <span>Flujo Horario</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChartTab('bahias')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeChartTab === 'bahias'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {/* SVG Icon BarChart */}
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="20" x2="12" y2="10" />
              <line x1="18" y1="20" x2="18" y2="4" />
              <line x1="6" y1="20" x2="6" y2="16" />
            </svg>
            <span>Uso por Bahía (E01-E10)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChartTab('zonas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeChartTab === 'zonas'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {/* SVG Icon PieChart */}
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
              <path d="M22 12A10 10 0 0 0 12 2v10z" />
            </svg>
            <span>Zonas (Est./Doc.)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveChartTab('rendimiento')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeChartTab === 'rendimiento'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {/* SVG Icon Activity / Gauge */}
            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
            <span>Rendimiento & Carriles</span>
          </button>
        </div>

        {/* Resumen de ocupación actual */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 font-semibold uppercase">Estado Actual:</span>
          <span
            className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
              talanqueraBloqueada
                ? 'bg-red-100 text-red-700'
                : disponiblesCount === 0
                ? 'bg-amber-100 text-amber-800'
                : 'bg-emerald-100 text-emerald-800'
            }`}
          >
            {talanqueraBloqueada ? 'BLOQUEADO' : disponiblesCount === 0 ? 'AFORO MÁXIMO' : `${ocupadosCount}/${totalEspacios} OCUPADAS (${porcentajeOcupacion}%)`}
          </span>
        </div>
      </div>

      {/* CONTENEDOR 1: FLUJO HORARIO (INGRESOS VS SALIDAS) */}
      {activeChartTab === 'flujo' && (
        <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                  <polyline points="17 6 23 6 23 12" />
                </svg>
                Curva de Flujo Horario de Tráfico (Ingresos y Salidas)
              </h4>
              <p className="text-[11px] text-slate-500">
                Picos de acceso durante la jornada académica en Campus Puerta Roja
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-medium">
              <span className="flex items-center gap-1.5 text-emerald-700">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Ingresos
              </span>
              <span className="flex items-center gap-1.5 text-sky-700">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500" /> Salidas
              </span>
            </div>
          </div>

          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={datosFlujoHorario} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIngresos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorSalidas" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="hora" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-700">
                          <p className="font-bold text-slate-200 mb-1">Hora: {label}</p>
                          <div className="flex flex-col gap-1 text-[11px]">
                            <span className="text-emerald-400 font-medium">
                              Ingresos: {payload[0]?.value} motocicletas
                            </span>
                            <span className="text-sky-400 font-medium">
                              Salidas: {payload[1]?.value} motocicletas
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area type="monotone" dataKey="ingresos" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorIngresos)" name="Ingresos" />
                <Area type="monotone" dataKey="salidas" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill="url(#colorSalidas)" name="Salidas" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* CONTENEDOR 2: USO Y ROTACIÓN POR BAHÍA (E01-E10) */}
      {activeChartTab === 'bahias' && (
        <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <svg className="w-4 h-4 text-sky-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <path d="M3 9h18M9 21V9" />
                </svg>
                Rotación Diaria y Estado Actual de Plazas (E01 a E10)
              </h4>
              <p className="text-[11px] text-slate-500">
                Verde: Actualmente Libre · Rojo: Actualmente Ocupada · Altura: Rotaciones hoy
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs font-medium">
              <span className="flex items-center gap-1.5 text-emerald-700">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> Bahía Libre
              </span>
              <span className="flex items-center gap-1.5 text-red-700">
                <span className="w-2.5 h-2.5 rounded-sm bg-red-500" /> Bahía Ocupada
              </span>
            </div>
          </div>

          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={datosBahias} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis dataKey="id" tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#cbd5e1' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white text-xs p-2.5 rounded-lg shadow-lg border border-slate-700">
                          <p className="font-bold text-slate-200">Plaza {data.id}</p>
                          <p className="text-[11px] text-slate-400">Sector: {data.zona}</p>
                          <div className="mt-1 pt-1 border-t border-slate-700 flex flex-col gap-0.5 text-[11px]">
                            <span className={data.estado === 'LIBRE' ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                              Estado: {data.estado}
                            </span>
                            <span className="text-sky-300">
                              Rotaciones acumuladas hoy: {data.rotacionesHoy} motos
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="rotacionesHoy" radius={[4, 4, 0, 0]}>
                  {datosBahias.map((entry, index) => (
                    <Cell key={`bar-cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* CONTENEDOR 3: ZONAS ESTUDIANTES VS DOCENTES */}
      {activeChartTab === 'zonas' && (
        <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <svg className="w-4 h-4 text-purple-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                Distribución por Zonas: Estudiantes (E01-E05) vs Docentes (E06-E10)
              </h4>
              <p className="text-[11px] text-slate-500">
                Comparativo de ocupación y cupos remanentes por estamento universitario
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            {/* Gráfico de Anillo Donut */}
            <div className="w-full h-56 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={datosDistribucionZonas}
                    dataKey="value"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    isAnimationActive={true}
                  >
                    {datosDistribucionZonas.map((entry, index) => (
                      <Cell key={`pie-cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0];
                        return (
                          <div className="bg-slate-900 text-white text-xs px-2.5 py-1.5 rounded shadow border border-slate-700">
                            <span className="font-semibold">{data.name}:</span> {data.value} plazas
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Tarjetas comparativas de zonas */}
            <div className="flex flex-col gap-2.5">
              <div className="p-3 rounded-xl bg-sky-50 border border-sky-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-900 uppercase">Zona Norte · Estudiantes</span>
                  <span className="text-xs font-mono font-bold text-sky-700">{estudiantesOcupados}/{estudiantesTotal} Ocupadas</span>
                </div>
                <div className="w-full bg-sky-200 h-2 rounded-full overflow-hidden mt-2">
                  <div
                    className="bg-sky-600 h-full rounded-full transition-all"
                    style={{ width: `${(estudiantesOcupados / estudiantesTotal) * 100}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-sky-800 font-medium mt-1.5">
                  <span>Plazas E01 - E05</span>
                  <span>{estudiantesLibres} plazas disponibles</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-50 border border-purple-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-purple-900 uppercase">Zona Sur · Docentes / Admin</span>
                  <span className="text-xs font-mono font-bold text-purple-700">{docentesOcupados}/{docentesTotal} Ocupadas</span>
                </div>
                <div className="w-full bg-purple-200 h-2 rounded-full overflow-hidden mt-2">
                  <div
                    className="bg-purple-600 h-full rounded-full transition-all"
                    style={{ width: `${(docentesOcupados / docentesTotal) * 100}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-purple-800 font-medium mt-1.5">
                  <span>Plazas E06 - E10</span>
                  <span>{docentesLibres} plazas disponibles</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONTENEDOR 4: RENDIMIENTO Y CARRILES (DOBLE CARRIL NORTE/SUR) */}
      {activeChartTab === 'rendimiento' && (
        <div className="bg-slate-50/70 border border-slate-200 rounded-xl p-4 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <svg className="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                </svg>
                Indicadores de Rendimiento y Balance de Doble Carril
              </h4>
              <p className="text-[11px] text-slate-500">
                Métricas de telemetría de acceso vial y disponibilidad de talanquera
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Gráfico de barras horizontales: Carril Norte vs Carril Sur */}
            <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-col gap-2">
              <span className="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <svg className="w-3.5 h-3.5 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="7 13 12 18 17 13" />
                  <polyline points="7 6 12 11 17 6" />
                </svg>
                Tráfico por Carril de Entrada (Doble Carril)
              </span>
              <div className="w-full h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={datosCarriles} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                    <XAxis type="number" tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 100]} />
                    <YAxis dataKey="carril" type="category" tick={{ fontSize: 11, fill: '#475569' }} />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-slate-900 text-white text-xs px-2 py-1 rounded shadow">
                              <span className="font-bold">{data.carril}:</span> {data.ingresos} motos ({data.porcentaje}%)
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="porcentaje" radius={[0, 4, 4, 0]}>
                      {datosCarriles.map((entry, index) => (
                        <Cell key={`carril-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                <span>Carril Norte: 52% del flujo</span>
                <span>Carril Sur: 48% del flujo</span>
              </div>
            </div>

            {/* Medidores de KPIs clave */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-col justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Tiempo Talanquera</span>
                <span className="text-xl font-extrabold text-slate-900 font-mono my-1">
                  {talanqueraBloqueada ? 'BLOQ' : '2.4s'}
                </span>
                <span className="text-[10px] text-slate-500 font-medium">Ciclo apertura/cierre</span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-col justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Tiempo de Espera</span>
                <span className="text-xl font-extrabold text-slate-900 font-mono my-1">
                  {disponiblesCount === 0 ? 'En Cola' : '0.0s'}
                </span>
                <span className="text-[10px] text-slate-500 font-medium">Demora en portería</span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-col justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Tasa Asignación</span>
                <span className="text-xl font-extrabold text-emerald-600 font-mono my-1">98.2%</span>
                <span className="text-[10px] text-slate-500 font-medium">Éxito en 1ª maniobra</span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-slate-200 flex flex-col justify-between">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Nodos IoT Activos</span>
                <span className="text-xl font-extrabold text-sky-600 font-mono my-1">10/10</span>
                <span className="text-[10px] text-slate-500 font-medium">Sensores 100% online</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OperatorAnalyticsChart;
