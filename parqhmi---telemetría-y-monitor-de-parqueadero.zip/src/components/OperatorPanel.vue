<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import type { EspacioInfo, EstadoTalanquera, MqttMensajeEstado } from '../types/parqueadero';
import { mqttHub } from '../services/mqttSimulationHub';
import OperatorAnalyticsWidget from './OperatorAnalyticsWidget.vue';

const props = defineProps<{
  espacios: EspacioInfo[];
  disponiblesCount: number;
  barrierState: EstadoTalanquera;
  talanqueraBloqueada: boolean;
  isAutoSimRunning: boolean;
}>();

const emit = defineEmits<{
  (e: 'cerrar'): void;
  (e: 'toggleAutoSim'): void;
}>();

// Pestaña activa en la consola de operador
type TabOperador = 'graficos' | 'control' | 'telemetria' | 'eventos';
const activeTab = ref<TabOperador>('graficos');

const selectedTargetBay = ref<string>('auto');
const mqttLogs = ref<MqttMensajeEstado[]>([]);
let unsubLogs: (() => void) | null = null;

const estaLleno = computed(() => props.disponiblesCount === 0);
const totalEspacios = computed(() => props.espacios.length || 10);
const ocupadosCount = computed(() => totalEspacios.value - props.disponiblesCount);
const porcentajeOcupacion = computed(() => {
  if (totalEspacios.value === 0) return 0;
  return Math.round((ocupadosCount.value / totalEspacios.value) * 100);
});

onMounted(() => {
  unsubLogs = mqttHub.subscribeMqttLogs((logs) => {
    mqttLogs.value = logs.slice(0, 20);
  });
});

onUnmounted(() => {
  unsubLogs?.();
});

function toggleBloqueo() {
  mqttHub.setBloqueoTalanquera(!props.talanqueraBloqueada);
}

function handleIngreso(origen?: 'norte' | 'sur') {
  const target = selectedTargetBay.value === 'auto' ? undefined : selectedTargetBay.value;
  mqttHub.triggerMotorcycleEntry(target, origen);
}

function handleSimultaneas() {
  mqttHub.triggerSimultaneousEntries();
}

function handleMotoEnEspera() {
  if (!estaLleno.value) return;
  mqttHub.triggerMotoEnEspera();
}

function handleSalida() {
  const target = selectedTargetBay.value === 'auto' ? undefined : selectedTargetBay.value;
  mqttHub.triggerMotorcycleExit(target);
}

function toggleEspacio(id: string) {
  const target = props.espacios.find((e) => e.id === id);
  if (!target) return;
  const next = target.estado === 'LIBRE' ? 'OCUPADO' : 'LIBRE';
  mqttHub.publishEstado(id, next, 'operador_caseta');
}

function resetAllFree() {
  props.espacios.forEach((esp) => {
    mqttHub.publishEstado(esp.id, 'LIBRE', 'operador_caseta');
  });
}

function fillAll() {
  props.espacios.forEach((esp) => {
    mqttHub.publishEstado(esp.id, 'OCUPADO', 'operador_caseta');
  });
}
</script>

<template>
  <div class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
    <div class="bg-white border border-slate-300 rounded-2xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
      
      <!-- Cabecera de Caseta con Navegación por Pestañas -->
      <div class="px-4 py-3 sm:px-6 sm:py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-center justify-center">
            <!-- SVG Icon Control Tower / Station -->
            <svg class="w-5 h-5 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
              <line x1="4" y1="22" x2="4" y2="15" />
            </svg>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-sm sm:text-base font-extrabold text-slate-900 tracking-wide uppercase">
                CONSOLA DE OPERADOR · CASETA DE CONTROL
              </h2>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                UNISUCRE
              </span>
            </div>
            <p class="text-[11px] text-slate-500 hidden sm:block">
              Supervisión de acceso vehicular, telemetría IoT, gráficos en tiempo real y bloqueo de barrera
            </p>
          </div>
        </div>

        <button
          type="button"
          @click="emit('cerrar')"
          class="px-3 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-xs text-slate-700 font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
        >
          <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
          <span>Volver a Pantalla</span>
        </button>
      </div>

      <!-- Barra de Pestañas de la Consola (Cero Emojis - Solo Iconos SVG) -->
      <div class="px-4 sm:px-6 pt-2 bg-slate-50 border-b border-slate-200 flex items-center gap-1 overflow-x-auto select-none">
        <!-- Pestaña 1: Gráficos y Analítica -->
        <button
          type="button"
          @click="activeTab = 'graficos'"
          class="px-3.5 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer shrink-0"
          :class="
            activeTab === 'graficos'
              ? 'bg-white text-emerald-700 border-emerald-600 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-100'
          "
        >
          <svg class="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
          </svg>
          <span>Gráficos y Analítica</span>
          <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        </button>

        <!-- Pestaña 2: Control de Acceso -->
        <button
          type="button"
          @click="activeTab = 'control'"
          class="px-3.5 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer shrink-0"
          :class="
            activeTab === 'control'
              ? 'bg-white text-blue-700 border-blue-600 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-100'
          "
        >
          <svg class="w-4 h-4 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
          </svg>
          <span>Control y Maniobras</span>
        </button>

        <!-- Pestaña 3: Telemetría de Sensores -->
        <button
          type="button"
          @click="activeTab = 'telemetria'"
          class="px-3.5 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer shrink-0"
          :class="
            activeTab === 'telemetria'
              ? 'bg-white text-indigo-700 border-indigo-600 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-100'
          "
        >
          <svg class="w-4 h-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="4" y="4" width="16" height="16" rx="2" />
            <rect x="9" y="9" width="6" height="6" />
            <line x1="9" y1="1" x2="9" y2="4" />
            <line x1="15" y1="1" x2="15" y2="4" />
            <line x1="9" y1="20" x2="9" y2="23" />
            <line x1="15" y1="20" x2="15" y2="23" />
            <line x1="20" y1="9" x2="23" y2="9" />
            <line x1="20" y1="14" x2="23" y2="14" />
            <line x1="1" y1="9" x2="4" y2="9" />
            <line x1="1" y1="14" x2="4" y2="14" />
          </svg>
          <span>Telemetría de Sensores</span>
        </button>

        <!-- Pestaña 4: Registro MQTT -->
        <button
          type="button"
          @click="activeTab = 'eventos'"
          class="px-3.5 py-2 rounded-t-xl text-xs font-bold transition-all flex items-center gap-2 border-b-2 cursor-pointer shrink-0"
          :class="
            activeTab === 'eventos'
              ? 'bg-white text-slate-800 border-slate-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-100'
          "
        >
          <svg class="w-4 h-4 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="8" y1="6" x2="21" y2="6" />
            <line x1="8" y1="12" x2="21" y2="12" />
            <line x1="8" y1="18" x2="21" y2="18" />
            <line x1="3" y1="6" x2="3.01" y2="6" />
            <line x1="3" y1="12" x2="3.01" y2="12" />
            <line x1="3" y1="18" x2="3.01" y2="18" />
          </svg>
          <span>Registro MQTT</span>
          <span v-if="mqttLogs.length > 0" class="px-1.5 py-0.2 rounded-full text-[9px] bg-slate-200 text-slate-700 font-mono">
            {{ mqttLogs.length }}
          </span>
        </button>
      </div>

      <!-- Tarjetas de Métricas Rápidas Siempre Visibles -->
      <div class="px-4 sm:px-6 py-2.5 bg-slate-100/70 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div class="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2.5 shadow-xs">
          <div class="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
          <div>
            <div class="text-[10px] font-bold text-slate-500 uppercase">Cupos Libres</div>
            <div class="text-sm font-extrabold text-emerald-700 font-mono">
              {{ disponiblesCount }} de {{ totalEspacios }}
            </div>
          </div>
        </div>

        <div class="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2.5 shadow-xs">
          <div class="w-8 h-8 rounded-lg bg-red-50 text-red-700 flex items-center justify-center shrink-0">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <div>
            <div class="text-[10px] font-bold text-slate-500 uppercase">Ocupadas</div>
            <div class="text-sm font-extrabold text-red-700 font-mono">
              {{ ocupadosCount }} ({{ porcentajeOcupacion }}%)
            </div>
          </div>
        </div>

        <div class="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2.5 shadow-xs">
          <div class="w-8 h-8 rounded-lg bg-sky-50 text-sky-700 flex items-center justify-center shrink-0">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </div>
          <div>
            <div class="text-[10px] font-bold text-slate-500 uppercase">Talanquera</div>
            <div class="text-xs font-extrabold font-mono" :class="talanqueraBloqueada ? 'text-red-700' : 'text-emerald-700'">
              {{ talanqueraBloqueada ? 'BLOQUEADA' : barrierState.toUpperCase() }}
            </div>
          </div>
        </div>

        <div class="bg-white p-2.5 rounded-xl border border-slate-200 flex items-center gap-2.5 shadow-xs">
          <div class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center shrink-0">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </div>
          <div>
            <div class="text-[10px] font-bold text-slate-500 uppercase">Simulación Auto</div>
            <div class="text-xs font-extrabold font-mono" :class="isAutoSimRunning ? 'text-emerald-700' : 'text-slate-500'">
              {{ isAutoSimRunning ? 'ACTIVA (8s)' : 'PAUSADA' }}
            </div>
          </div>
        </div>
      </div>

      <!-- Contenido Principal con Scroll según la pestaña activa -->
      <div class="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
        
        <!-- PESTAÑA 1: GRÁFICOS Y ANALÍTICA (RECHARTS) -->
        <div v-show="activeTab === 'graficos'" class="space-y-4">
          <OperatorAnalyticsWidget
            :espacios="espacios"
            :disponibles-count="disponiblesCount"
            :total-espacios="totalEspacios"
            :barrier-state="barrierState"
            :talanquera-bloqueada="talanqueraBloqueada"
            :is-auto-sim-running="isAutoSimRunning"
          />
        </div>

        <!-- PESTAÑA 2: CONTROL Y MANIOBRAS -->
        <div v-show="activeTab === 'control'" class="space-y-6">
          
          <!-- Bloqueo de Talanquera -->
          <div
            class="rounded-xl p-4 border transition-all"
            :class="talanqueraBloqueada ? 'bg-red-50 border-red-300' : 'bg-slate-50 border-slate-200'"
          >
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div class="flex items-center gap-2">
                  <span class="w-3 h-3 rounded-full" :class="talanqueraBloqueada ? 'bg-red-600 animate-pulse' : 'bg-emerald-600'" />
                  <h3 class="text-sm font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                    <svg class="w-4 h-4 text-slate-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                    </svg>
                    Control Físico de Barrera (Talanquera)
                  </h3>
                </div>
                <p class="text-xs text-slate-600 mt-1 max-w-md">
                  {{ talanqueraBloqueada 
                      ? 'La talanquera está bloqueada en posición cerrada cruzando la calzada. El paso de vehículos está suspendido y la pantalla de usuario advierte el bloqueo.' 
                      : 'La talanquera opera en modo automático normal al detectar vehículos en la entrada.' }}
                </p>
              </div>

              <button
                type="button"
                @click="toggleBloqueo"
                class="px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-md active:scale-95 shrink-0 flex items-center gap-2"
                :class="talanqueraBloqueada 
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20' 
                  : 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/20'"
              >
                <svg v-if="talanqueraBloqueada" class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 9.9-1" />
                </svg>
                <svg v-else class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <span>{{ talanqueraBloqueada ? 'DESBLOQUEAR TALANQUERA' : 'BLOQUEAR TALANQUERA' }}</span>
              </button>
            </div>
          </div>

          <!-- Pruebas de Tráfico Vehicular (Cero Emojis - Iconos SVG) -->
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <svg class="w-4 h-4 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <polygon points="10 8 16 12 10 16 10 8" />
                </svg>
                Pruebas de Tráfico Vehicular (Simulación de Maniobras)
              </h3>
              <span v-if="talanqueraBloqueada" class="text-xs text-red-600 font-semibold">
                * Ingreso inhabilitado por bloqueo de talanquera
              </span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <!-- Botón Ingreso Calle Norte (Icono SVG flecha arriba) -->
              <button
                type="button"
                @click="handleIngreso('norte')"
                :disabled="talanqueraBloqueada"
                class="py-2.5 px-3 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                :class="talanqueraBloqueada
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'"
              >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="19" x2="12" y2="5" />
                  <polyline points="5 12 12 5 19 12" />
                </svg>
                <span>INGRESO CALLE NORTE</span>
              </button>

              <!-- Botón Ingreso Calle Sur (Icono SVG flecha abajo) -->
              <button
                type="button"
                @click="handleIngreso('sur')"
                :disabled="talanqueraBloqueada"
                class="py-2.5 px-3 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                :class="talanqueraBloqueada
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                  : 'bg-sky-600 hover:bg-sky-700 text-white shadow-sky-600/20'"
              >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <polyline points="19 12 12 19 5 12" />
                </svg>
                <span>INGRESO CALLE SUR</span>
              </button>

              <!-- Botón Simultáneas (Icono SVG rayo / dual) -->
              <button
                type="button"
                @click="handleSimultaneas"
                :disabled="talanqueraBloqueada"
                class="py-2.5 px-3 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                :class="talanqueraBloqueada
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-600/20'"
              >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                </svg>
                <span>SIMULTÁNEAS (NORTE + SUR)</span>
              </button>

              <!-- Botón Moto en Espera (Icono SVG reloj / hourglass) -->
              <button
                type="button"
                @click="handleMotoEnEspera"
                :disabled="talanqueraBloqueada || !estaLleno"
                class="py-2.5 px-3 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-sm"
                :class="talanqueraBloqueada || !estaLleno
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                  : 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/30 cursor-pointer animate-pulse ring-2 ring-amber-400'"
                :title="!estaLleno ? 'Solo disponible cuando el parqueadero esté lleno (0 cupos)' : 'Simular moto esperando cupo libre en portería'"
              >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12 6 12 12 16 14" />
                </svg>
                <span>MOTO EN ESPERA {{ !estaLleno ? '(SOLO CON LLENO)' : '(ACTIVO)' }}</span>
              </button>
            </div>

            <!-- Explicación de Moto en Espera con SVG -->
            <div
              v-if="!estaLleno"
              class="text-[11px] text-slate-600 bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between gap-2"
            >
              <div class="flex items-center gap-2">
                <svg class="w-4 h-4 text-slate-400 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="12" y1="16" x2="12" y2="12" />
                  <line x1="12" y1="8" x2="12.01" y2="8" />
                </svg>
                <span>
                  Botón <strong>Moto en Espera</strong> inhabilitado: hay <strong>{{ disponiblesCount }} cupos libres</strong>. Una moto solo espera cuando el aforo está al 100%.
                </span>
              </div>
              <button
                type="button"
                @click="fillAll"
                class="text-xs font-bold text-amber-700 hover:text-amber-800 underline cursor-pointer shrink-0"
              >
                Llenar Plazas
              </button>
            </div>
            <div
              v-else
              class="text-[11px] text-amber-900 bg-amber-50 border border-amber-300 rounded-xl p-2.5 font-medium flex items-center gap-2"
            >
              <svg class="w-4 h-4 text-amber-600 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                <polyline points="22 4 12 14.01 9 11.01" />
              </svg>
              <span>
                <strong>Aforo Completo (0 cupos):</strong> Botón activo. Pulsa para simular la moto que llega a portería y espera a que un puesto se desocupe.
              </span>
            </div>

            <!-- Botón Salida de Moto (Icono SVG flecha derecha) -->
            <div class="pt-1">
              <button
                type="button"
                @click="handleSalida"
                class="w-full py-2.5 px-4 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-900 text-white transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm shadow-slate-800/20"
              >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
                <span>SALIDA DE MOTO (HACIA PENDÓN)</span>
              </button>
            </div>

            <div class="flex items-center justify-between text-xs pt-1">
              <span class="text-slate-600 font-medium">Destino de la maniobra:</span>
              <select
                v-model="selectedTargetBay"
                class="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-blue-700 font-bold focus:outline-hidden cursor-pointer shadow-xs"
              >
                <option value="auto">Automático (Primera disponible)</option>
                <option v-for="esp in espacios" :key="esp.id" :value="esp.id">
                  Plaza {{ esp.id }} ({{ esp.estado }})
                </option>
              </select>
            </div>
          </div>

          <!-- Gestión Individual de Plazas -->
          <div class="space-y-2">
            <div class="flex items-center justify-between">
              <h3 class="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <svg class="w-4 h-4 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="7" height="7" />
                  <rect x="14" y="3" width="7" height="7" />
                  <rect x="14" y="14" width="7" height="7" />
                  <rect x="3" y="14" width="7" height="7" />
                </svg>
                Forzar Estado de Plazas
              </h3>
              <div class="flex items-center gap-2">
                <button
                  type="button"
                  @click="resetAllFree"
                  class="text-[11px] font-semibold text-emerald-600 hover:underline cursor-pointer flex items-center gap-1"
                >
                  <svg class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="1 4 1 10 7 10" />
                    <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
                  </svg>
                  <span>Liberar todas</span>
                </button>
                <span class="text-slate-300">|</span>
                <button
                  type="button"
                  @click="fillAll"
                  class="text-[11px] font-semibold text-red-600 hover:underline cursor-pointer flex items-center gap-1"
                >
                  <svg class="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" />
                  </svg>
                  <span>Llenar todas</span>
                </button>
              </div>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-1.5 w-full">
              <button
                v-for="esp in espacios"
                :key="esp.id"
                type="button"
                @click="toggleEspacio(esp.id)"
                class="p-2 rounded-lg border text-center transition-colors cursor-pointer flex flex-col items-center gap-1 min-w-0 overflow-hidden shadow-xs"
                :class="esp.estado === 'LIBRE' 
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800 hover:bg-emerald-100' 
                  : 'bg-red-50 border-red-300 text-red-800 hover:bg-red-100'"
              >
                <span class="font-extrabold text-xs truncate">{{ esp.id }}</span>
                <span class="text-[9px] font-bold uppercase truncate">
                  {{ esp.estado }}
                </span>
              </button>
            </div>
          </div>

          <!-- Simulación Continua -->
          <div class="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <div class="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <svg class="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
                Simulación Autónoma de Demostración
              </div>
              <div class="text-[11px] text-slate-500">
                Genera llegadas y salidas de motos periódicas
              </div>
            </div>

            <button
              type="button"
              @click="emit('toggleAutoSim')"
              class="px-4 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
              :class="isAutoSimRunning ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'"
            >
              <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <polyline points="12 6 12 12 14 14" />
              </svg>
              <span>{{ isAutoSimRunning ? 'ACTIVADA' : 'DESACTIVADA' }}</span>
            </button>
          </div>

        </div>

        <!-- PESTAÑA 3: TELEMETRÍA DE SENSORES IOT -->
        <div v-show="activeTab === 'telemetria'" class="space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <svg class="w-4 h-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
                  <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
                  <line x1="6" y1="6" x2="6.01" y2="6" />
                  <line x1="6" y1="18" x2="6.01" y2="18" />
                </svg>
                Diagrama de Telemetría IoT en Tiempo Real (Nodos & Actuadores)
              </h3>
              <p className="text-[11px] text-slate-500">
                Estado de microcontroladores ESP32, sensores ultrasónicos HC-SR04, fotoceldas y lazo inductivo
              </p>
            </div>
            <span class="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              BROKER MQTT ONLINE (QoS 1)
            </span>
          </div>

          <!-- Matriz de Sensores de Bahía -->
          <div class="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            <div
              v-for="esp in espacios"
              :key="esp.id"
              class="p-3 rounded-xl border flex flex-col justify-between transition-all bg-white"
              :class="esp.estado === 'LIBRE' ? 'border-emerald-300' : 'border-red-300'"
            >
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold font-mono text-slate-800">{{ esp.id }}</span>
                <span
                  class="w-2 h-2 rounded-full"
                  :class="esp.estado === 'LIBRE' ? 'bg-emerald-500' : 'bg-red-500 animate-pulse'"
                />
              </div>
              <div class="my-1.5 text-[10px]">
                <div class="text-slate-400">Sensor Ultrasónico:</div>
                <div class="font-mono font-bold" :class="esp.estado === 'LIBRE' ? 'text-emerald-700' : 'text-red-700'">
                  {{ esp.estado === 'LIBRE' ? 'Distancia > 150 cm' : 'Distancia < 45 cm' }}
                </div>
              </div>
              <div class="text-[9px] text-slate-400 font-mono">
                Nodo: {{ esp.nodo || 'esp32_bay_' + esp.id.toLowerCase() }}
              </div>
            </div>
          </div>

          <!-- Actuadores y Sensores de Acceso -->
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div class="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <svg class="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                </svg>
                Servomotor Talanquera
              </div>
              <div class="mt-2 text-xs font-mono">
                <div>Ángulo: <b class="text-slate-900">{{ barrierState === 'abierta' ? '90° (Levantada)' : '0° (Horizontal)' }}</b></div>
                <div class="text-slate-500 mt-0.5">Par de bloqueo: {{ talanqueraBloqueada ? 'Traba activa' : 'Normal' }}</div>
              </div>
            </div>

            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div class="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <svg class="w-4 h-4 text-sky-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M2 12h20M7 8l-4 4 4 4M17 8l4 4-4 4" />
                </svg>
                Lazos Inductivos (Entrada)
              </div>
              <div class="mt-2 text-xs font-mono">
                <div>Carril Norte: <b class="text-emerald-700">Listo (Presencia)</b></div>
                <div>Carril Sur: <b class="text-sky-700">Listo (Presencia)</b></div>
              </div>
            </div>

            <div class="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <div class="text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                <svg class="w-4 h-4 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="2" x2="12" y2="6" />
                  <line x1="12" y1="18" x2="12" y2="22" />
                  <line x1="4.93" y1="4.93" x2="7.76" y2="7.76" />
                  <line x1="16.24" y1="16.24" x2="19.07" y2="19.07" />
                  <line x1="2" y1="12" x2="6" y2="12" />
                  <line x1="18" y1="12" x2="22" y2="12" />
                </svg>
                Fotocelda Infrarroja
              </div>
              <div class="mt-2 text-xs font-mono">
                <div>Haz Infrarrojo: <b class="text-emerald-700">Alineado</b></div>
                <div class="text-slate-500 mt-0.5">Anti-aplastamiento vehicular</div>
              </div>
            </div>
          </div>
        </div>

        <!-- PESTAÑA 4: REGISTRO MQTT Y EVENTOS -->
        <div v-show="activeTab === 'eventos'" class="space-y-3">
          <div class="flex items-center justify-between">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
              <svg class="w-4 h-4 text-slate-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="4 17 10 11 4 5" />
                <line x1="12" y1="19" x2="20" y2="19" />
              </svg>
              Registro de Mensajes Mosquitto MQTT en Vivo
            </h3>
            <span class="text-[11px] font-mono text-slate-500">
              unisucre/puertaroja/motos/#
            </span>
          </div>

          <div class="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-xs">
            <div class="overflow-x-auto max-h-80">
              <table class="w-full text-left text-xs">
                <thead class="bg-slate-100 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200 sticky top-0">
                  <tr>
                    <th class="px-3 py-2">Hora</th>
                    <th class="px-3 py-2">Tópico MQTT</th>
                    <th class="px-3 py-2">Estado</th>
                    <th class="px-3 py-2">QoS</th>
                    <th class="px-3 py-2">Dirección</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-mono text-[11px]">
                  <tr v-if="mqttLogs.length === 0" class="text-slate-400">
                    <td colspan="5" class="px-3 py-6 text-center">
                      Esperando eventos MQTT en el broker...
                    </td>
                  </tr>
                  <tr
                    v-for="(log, idx) in mqttLogs"
                    :key="idx"
                    class="hover:bg-slate-50 transition-colors"
                  >
                    <td class="px-3 py-1.5 text-slate-500">
                      {{ new Date(log.timestamp).toLocaleTimeString() }}
                    </td>
                    <td class="px-3 py-1.5 font-bold text-slate-800">
                      {{ log.topic }}
                    </td>
                    <td class="px-3 py-1.5">
                      <span
                        class="px-2 py-0.5 rounded text-[10px] font-bold"
                        :class="log.payload.estado === 'LIBRE' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'"
                      >
                        {{ log.payload.estado }}
                      </span>
                    </td>
                    <td class="px-3 py-1.5 text-slate-600">
                      QoS {{ log.qos }}
                    </td>
                    <td class="px-3 py-1.5">
                      <span class="text-slate-500 font-bold">
                        {{ log.direccion === 'in' ? 'RECEPCIÓN (IN)' : 'PUBLICACIÓN (OUT)' }}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div>

      <!-- Pie de Caseta -->
      <div class="px-4 sm:px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
        <div class="flex items-center gap-2">
          <span>Talanquera: <strong :class="talanqueraBloqueada ? 'text-red-600' : 'text-emerald-600'">{{ talanqueraBloqueada ? 'BLOQUEADA' : 'EN SERVICIO' }}</strong></span>
          <span class="text-slate-300">·</span>
          <span>Aforo: <strong class="text-slate-800">{{ porcentajeOcupacion }}%</strong></span>
        </div>
        <button
          type="button"
          @click="emit('cerrar')"
          class="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-medium transition-colors cursor-pointer text-xs flex items-center gap-1.5"
        >
          <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="9 18 15 12 9 6" />
          </svg>
          <span>Cerrar Consola</span>
        </button>
      </div>

    </div>
  </div>
</template>
