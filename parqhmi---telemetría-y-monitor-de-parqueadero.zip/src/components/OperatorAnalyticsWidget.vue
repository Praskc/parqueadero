<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch } from 'vue';
import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { OperatorAnalyticsChart } from './OperatorAnalyticsChart';
import type { EspacioInfo, EstadoTalanquera } from '../types/parqueadero';

const props = defineProps<{
  espacios: EspacioInfo[];
  disponiblesCount: number;
  totalEspacios: number;
  barrierState: EstadoTalanquera;
  talanqueraBloqueada: boolean;
  isAutoSimRunning: boolean;
}>();

const chartContainer = ref<HTMLDivElement | null>(null);
let reactRoot: Root | null = null;

function renderChart() {
  if (!chartContainer.value) return;

  if (!reactRoot) {
    reactRoot = createRoot(chartContainer.value);
  }

  reactRoot.render(
    React.createElement(OperatorAnalyticsChart, {
      espacios: props.espacios,
      disponiblesCount: props.disponiblesCount,
      totalEspacios: props.totalEspacios,
      barrierState: props.barrierState,
      talanqueraBloqueada: props.talanqueraBloqueada,
      isAutoSimRunning: props.isAutoSimRunning,
    })
  );
}

onMounted(() => {
  renderChart();
});

watch(
  [
    () => props.espacios,
    () => props.disponiblesCount,
    () => props.barrierState,
    () => props.talanqueraBloqueada,
    () => props.isAutoSimRunning,
  ],
  () => {
    renderChart();
  },
  { deep: true }
);

onUnmounted(() => {
  if (reactRoot) {
    reactRoot.unmount();
    reactRoot = null;
  }
});
</script>

<template>
  <div class="w-full">
    <div ref="chartContainer" class="w-full" />
  </div>
</template>
